//!1 this is my old fully working code
// import { useState, useEffect } from "react";
// import "../styles/macro.css";
// import Slid from "./Slid";

// /* =====================================================
//    CALORIE CONVERSION CONSTANTS
//    Calories per gram for each macronutrient.
//    Slightly adjusted to closely match calculator.net.
// ===================================================== */
// const KCAL = {
//   protein: 4.1,
//   carbs: 3.75,
//   fat: 8.8,
// };

// function Macro() {
//   const [gender, setGender] = useState(localStorage.getItem("gender") || "male");
//   const [age, setAge] = useState(localStorage.getItem("age") || "");
//   const [weight, setWeight] = useState(localStorage.getItem("weight") || "");
//   const [height, setHeight] = useState(localStorage.getItem("height") || "");
//   const [activityLevel, setActivityLevel] = useState(
//     parseFloat(localStorage.getItem("activityLevel")) || 1.2
//   );
//   const [goal, setGoal] = useState(localStorage.getItem("goal") || "m");

//   /* Selected macro preset */
//   const [macroType, setMacroType] = useState("balanced");

//   const [results, setResults] = useState(null);

//   useEffect(() => {
//     localStorage.setItem("gender", gender);
//     localStorage.setItem("age", age);
//     localStorage.setItem("weight", weight);
//     localStorage.setItem("height", height);
//     localStorage.setItem("activityLevel", activityLevel);
//     localStorage.setItem("goal", goal);
//   }, [gender, age, weight, height, activityLevel, goal]);

//   /* =====================================================
//      MAIN MACRO CALCULATION FUNCTION
//   ===================================================== */
//   const calculateMacros = () => {
//     if (!age || !weight || !height) {
//       alert("Please fill in all fields.");
//       return;
//     }

//     const numAge = Number(age);
//     const numWeight = Number(weight);
//     const numHeight = Number(height);

//     /* =====================================================
//        BMR (Basal Metabolic Rate)
//        Mifflin-St Jeor Equation
//     ===================================================== */
//     const bmr =
//       gender === "male"
//         ? 10 * numWeight + 6.25 * numHeight - 5 * numAge + 5
//         : 10 * numWeight + 6.25 * numHeight - 5 * numAge - 161;

//     /* TDEE (Total Daily Energy Expenditure) */
//     const tdee = bmr * activityLevel;

//     /* =====================================================
//        CALORIE GOAL ADJUSTMENT
//        Deficit or surplus based on goal
//     ===================================================== */
//     let calorieGoal = tdee;
//     if (goal === "l") calorieGoal -= 250;
//     if (goal === "l1") calorieGoal -= 500;
//     if (goal === "l2") calorieGoal -= 1000;
//     if (goal === "g") calorieGoal += 250;
//     if (goal === "g1") calorieGoal += 500;
//     if (goal === "g2") calorieGoal += 1000;

//     /* =====================================================
//        MACRO PRESETS
//        Initial calorie distribution only (not hard rules)
//     ===================================================== */
//     const macroPresets = {
//       balanced: { protein: 0.25, carbs: 0.5, fat: 0.25 },
//       lowFat: { protein: 0.275, carbs: 0.525, fat: 0.2 },
//       lowCarb: { protein: 0.3, carbs: 0.4, fat: 0.3 },
//       highProtein: { protein: 0.35, carbs: 0.425, fat: 0.225 },
//     };

//     const { protein: pPct, carbs: cPct, fat: fPct } =
//       macroPresets[macroType];

//     /* Convert calorie percentages into grams */
//     const protein = (pPct * calorieGoal) / KCAL.protein;
//     const carbs = (cPct * calorieGoal) / KCAL.carbs;
//     const fat = (fPct * calorieGoal) / KCAL.fat;

//     /* =====================================================
//        HARD MACRO RANGES (calculator.net style)
//        These constraints override preset values
//     ===================================================== */

//     /* Protein minimum rules */
//     let proteinMin = Math.max(60, numWeight * 1.0);

//     const proteinFromCalories = (0.1 * calorieGoal) / KCAL.protein;
//     if (proteinFromCalories > proteinMin) {
//       proteinMin = proteinFromCalories;
//     }

//     if (goal === "g" || goal === "g1" || goal === "g2") {
//       proteinMin = Math.max(proteinMin, numWeight * 1.0);
//     }

//     const proteinMax = (0.35 * calorieGoal) / KCAL.protein;

//     /* Fat range: 20% – 35% of calories */
//     const fatMin = (0.2 * calorieGoal) / KCAL.fat;
//     const fatMax = (0.35 * calorieGoal) / KCAL.fat;

//     /* Carb range */
//     const carbMin = (0.4 * calorieGoal) / KCAL.carbs;

//     /* Carb max is derived from remaining calories */
//     const carbMax =
//       (calorieGoal -
//         proteinMin * KCAL.protein -
//         fatMin * KCAL.fat) /
//       KCAL.carbs;

//     const macros = {
//       protein: { min: proteinMin, max: proteinMax },
//       carbs: { min: carbMin, max: carbMax },
//       fat: { min: fatMin, max: fatMax },
//     };

//     /* =====================================================
//        FINAL RESULTS (CLAMPED TO RANGES)
//     ===================================================== */
//     setResults({
//       totalCalories: Math.round(calorieGoal),
//       protein: Math.min(
//         Math.max(protein, macros.protein.min),
//         macros.protein.max
//       ),
//       carbs: Math.min(
//         Math.max(carbs, macros.carbs.min),
//         macros.carbs.max
//       ),
//       fat: Math.min(
//         Math.max(fat, macros.fat.min),
//         macros.fat.max
//       ),
//       proteinRange: macros.protein,
//       carbsRange: macros.carbs,
//       fatRange: macros.fat,
//     });
//   };

//   return (
//     <div className="App">
//       <h1>Macro Calculator</h1>

//       <div className="form-container">
//         <label>Gender:</label>
//         <select value={gender} onChange={(e) => setGender(e.target.value)}>
//           <option value="male">Male</option>
//           <option value="female">Female</option>
//         </select>

//         <label>Age:</label>
//         <input
//           type="number"
//           value={age}
//           onChange={(e) => setAge(e.target.value)}
//         />

//         <label>Height (cm):</label>
//         <input
//           type="number"
//           value={height}
//           onChange={(e) => setHeight(e.target.value)}
//         />

//         <label>Weight (kg):</label>
//         <input
//           type="number"
//           value={weight}
//           onChange={(e) => setWeight(e.target.value)}
//         />

//         <label>Activity Level:</label>
//         <select
//           value={activityLevel}
//           onChange={(e) => setActivityLevel(parseFloat(e.target.value))}
//         >
//           <option value={1}>Basal Metabolic Rate (BMR)</option>
//           <option value={1.2}>Sedentary: little or no exercise</option>
//           <option value={1.375}>Light: exercise 1-3 times/week</option>
//           <option value={1.465}>Moderate: exercise 4-5 times/week</option>
//           <option value={1.55}>
//             Active: daily exercise or intense exercise 3-4 times/week
//           </option>
//           <option value={1.725}>
//             Very Active: intense exercise 6-7 times/week
//           </option>
//           <option value={1.9}>
//             Extra Active: very intense exercise or physical job
//           </option>
//         </select>

//         <label>Goal:</label>
//         <select value={goal} onChange={(e) => setGoal(e.target.value)}>
//           <option value="m">Maintain weight</option>
//           <option value="l">Mild weight loss</option>
//           <option value="l1">Weight loss 1 lb/week</option>
//           <option value="l2">Extreme weight loss</option>
//           <option value="g">Mild weight gain</option>
//           <option value="g1">Weight gain 1 lb/week</option>
//           <option value="g2">Extreme weight gain</option>
//         </select>

//         <label>Macro Type:</label>
//         <select
//           value={macroType}
//           onChange={(e) => setMacroType(e.target.value)}
//         >
//           <option value="balanced">Balanced</option>
//           <option value="lowFat">Low Fat</option>
//           <option value="lowCarb">Low Carb</option>
//           <option value="highProtein">High Protein</option>
//         </select>

//         <button onClick={calculateMacros}>Calculate</button>
//       </div>

//       {results && (
//         <div className="results">
//           <h2>Results</h2>
//           <h3>Total Calories: {results.totalCalories} kcal/day</h3>

//           <p>
//             <b>Protein:</b> {Math.round(results.protein)} g/day (Range:{" "}
//             {Math.round(results.proteinRange.min)} –{" "}
//             {Math.round(results.proteinRange.max)} g)
//           </p>

//           <p>
//             <b>Carbs:</b> {Math.round(results.carbs)} g/day (Range:{" "}
//             {Math.round(results.carbsRange.min)} –{" "}
//             {Math.round(results.carbsRange.max)} g)
//           </p>

//           <p>
//             <b>Fat:</b> {Math.round(results.fat)} g/day (Range:{" "}
//             {Math.round(results.fatRange.min)} –{" "}
//             {Math.round(results.fatRange.max)} g)
//           </p>

//           <Slid results={results} setResults={setResults} />
//         </div>
//       )}
//     </div>
//   );
// }

// export default Macro;

// //! This is my new code with temperature and hunger level added
import { useState, useEffect } from "react";
import "../styles/macro.css";
import Slid from "./Slid";

/* =====================================================
   CALORIE CONVERSION CONSTANTS
===================================================== */
const KCAL = {
  protein: 4.1,
  carbs: 3.75,
  fat: 8.8,
};

/* =====================================================
   MEAL TIME RANGES (24h)
===================================================== */
const MEAL_RANGES = {
  Breakfast: [3, 11],
  Lunch: [11, 16],
  Snacks: [16, 17],
  Dinner: [17, 3],
};

/* =====================================================
   MEAL CALORIE DISTRIBUTION (ICMR)
===================================================== */
const MEAL_PERCENTAGES = {
  Breakfast: [0.2, 0.25],
  Lunch: [0.3, 0.35],
  Snacks: [0.1, 0.15],
  Dinner: [0.3, 0.35],
};

/* =====================================================
   TEMPERATURE OPTIONS
===================================================== */
const TEMPERATURE_FACTORS = {
  cold: 1.2,
  moderateCold: 1.075,
  neutral: 1.0,
  warm: 1.0,
  hot: 1.075,
  extremeHot: 1.15,
};

/* =====================================================
   CURRENT MEAL DETECTION
===================================================== */
const getCurrentMeal = () => {
  const hour = new Date().getHours();
  for (const meal in MEAL_RANGES) {
    const [start, end] = MEAL_RANGES[meal];
    if (start < end) {
      if (hour >= start && hour < end) return meal;
    } else {
      if (hour >= start || hour < end) return meal;
    }
  }
  return "Dinner";
};

/* =====================================================
   HUNGER BASED SELECTION
===================================================== */
const selectByHunger = (min, max, hunger) => {
  if (hunger === "low") return min;
  if (hunger === "high") return max;
  return (min + max) / 2;
};

function Macro() {
  const [gender, setGender] = useState(localStorage.getItem("gender") || "male");
  const [age, setAge] = useState(localStorage.getItem("age") || "");
  const [weight, setWeight] = useState(localStorage.getItem("weight") || "");
  const [height, setHeight] = useState(localStorage.getItem("height") || "");
  const [activityLevel, setActivityLevel] = useState(
    parseFloat(localStorage.getItem("activityLevel")) || 1.2
  );
  const [goal, setGoal] = useState(localStorage.getItem("goal") || "m");
  const [temperatureType, setTemperatureType] = useState(
    localStorage.getItem("temperatureType") || "neutral"
  );
  const [hunger, setHunger] = useState(
    localStorage.getItem("hunger") || "normal"
  );
  const [macroType, setMacroType] = useState("balanced");

  const [results, setResults] = useState(null);
  const [mealInfo, setMealInfo] = useState(null);

  useEffect(() => {
    localStorage.setItem("gender", gender);
    localStorage.setItem("age", age);
    localStorage.setItem("weight", weight);
    localStorage.setItem("height", height);
    localStorage.setItem("activityLevel", activityLevel);
    localStorage.setItem("goal", goal);
    localStorage.setItem("temperatureType", temperatureType);
    localStorage.setItem("hunger", hunger);
  }, [gender, age, weight, height, activityLevel, goal, temperatureType, hunger]);

  const calculateMacros = () => {
    if (!age || !weight || !height) {
      alert("Please fill in all fields.");
      return;
    }

    const numAge = Number(age);
    const numWeight = Number(weight);
    const numHeight = Number(height);

    /* ================= BMR ================= */
    const bmr =
      gender === "male"
        ? 10 * numWeight + 6.25 * numHeight - 5 * numAge + 5
        : 10 * numWeight + 6.25 * numHeight - 5 * numAge - 161;

    const adjustedBmr =
      bmr * (TEMPERATURE_FACTORS[temperatureType] || 1);

    /* ================= TDEE ================= */
    let calorieGoal = adjustedBmr * activityLevel;

    /* ================= GOAL ================= */
    if (goal === "l") calorieGoal -= 250;
    if (goal === "l1") calorieGoal -= 500;
    if (goal === "l2") calorieGoal -= 1000;
    if (goal === "g") calorieGoal += 250;
    if (goal === "g1") calorieGoal += 500;
    if (goal === "g2") calorieGoal += 1000;

    /* ================= MEAL ================= */
    const currentMeal = getCurrentMeal();
    const [minPct, maxPct] = MEAL_PERCENTAGES[currentMeal];

    const mealMin = calorieGoal * minPct;
    const mealMax = calorieGoal * maxPct;
    const mealSelected = selectByHunger(mealMin, mealMax, hunger);

    setMealInfo({
      meal: currentMeal,
      min: Math.round(mealMin),
      max: Math.round(mealMax),
      selected: Math.round(mealSelected),
    });

    /* ================= DAILY MACRO RANGES (DOCUMENT) ================= */
    let proteinMin = Math.max(60, numWeight * 1);
    const proteinFromCalories = (0.1 * calorieGoal) / KCAL.protein;
    if (proteinFromCalories > proteinMin) proteinMin = proteinFromCalories;

    // 🔥 GAIN OVERRIDE (DOCUMENT)
    if (goal === "g" || goal === "g1" || goal === "g2") {
      proteinMin = Math.max(proteinMin, numWeight * 1);
    }

    const proteinMax = (0.35 * calorieGoal) / KCAL.protein;

    const fatMin = (0.2 * calorieGoal) / KCAL.fat;
    const fatMax = (0.35 * calorieGoal) / KCAL.fat;

    const carbMin = (0.4 * calorieGoal) / KCAL.carbs;
    let carbMax =
      (calorieGoal -
        proteinMin * KCAL.protein -
        fatMin * KCAL.fat) /
      KCAL.carbs;

    // 🔥 safety
    if (carbMax < carbMin) carbMax = carbMin;

    /* ================= MACRO PRESETS ================= */
    const macroPresets = {
      balanced: { protein: 0.25, carbs: 0.5, fat: 0.25 },
      lowFat: { protein: 0.275, carbs: 0.525, fat: 0.2 },
      lowCarb: { protein: 0.3, carbs: 0.4, fat: 0.3 },
      highProtein: { protein: 0.35, carbs: 0.425, fat: 0.225 },
    };

    const { protein: pPct, carbs: cPct, fat: fPct } =
      macroPresets[macroType];

    const dailyProtein = Math.min(
      Math.max((pPct * calorieGoal) / KCAL.protein, proteinMin),
      proteinMax
    );
    const dailyCarbs = Math.min(
      Math.max((cPct * calorieGoal) / KCAL.carbs, carbMin),
      carbMax
    );
    const dailyFat = Math.min(
      Math.max((fPct * calorieGoal) / KCAL.fat, fatMin),
      fatMax
    );

    const mealPctUsed =
      hunger === "low" ? minPct :
      hunger === "high" ? maxPct :
      (minPct + maxPct) / 2;

    setResults({
      totalCalories: Math.round(calorieGoal),

      protein: dailyProtein,
      carbs: dailyCarbs,
      fat: dailyFat,

      proteinRange: { min: proteinMin, max: proteinMax },
      carbsRange: { min: carbMin, max: carbMax },
      fatRange: { min: fatMin, max: fatMax },

      mealProteinRange: {
        min: proteinMin * minPct,
        max: proteinMax * maxPct,
      },
      mealCarbRange: {
        min: carbMin * minPct,
        max: carbMax * maxPct,
      },
      mealFatRange: {
        min: fatMin * minPct,
        max: fatMax * maxPct,
      },

      mealProteinSelected: dailyProtein * mealPctUsed,
      mealCarbSelected: dailyCarbs * mealPctUsed,
      mealFatSelected: dailyFat * mealPctUsed,
    });
  };

  return (
    <div className="App">
      <h1>Macro Calculator</h1>

      <div className="form-container">
        <label>Gender:</label>
        <select value={gender} onChange={(e) => setGender(e.target.value)}>
          <option value="male">Male</option>
          <option value="female">Female</option>
        </select>

        <label>Age:</label>
        <input
          type="number"
          value={age}
          onChange={(e) => setAge(e.target.value)}
        />

        <label>Height (cm):</label>
        <input
          type="number"
          value={height}
          onChange={(e) => setHeight(e.target.value)}
        />

        <label>Weight (kg):</label>
        <input
          type="number"
          value={weight}
          onChange={(e) => setWeight(e.target.value)}
        />

        <label>Environment Temperature:</label>
        <select
          value={temperatureType}
          onChange={(e) => setTemperatureType(e.target.value)}
        >
          <option value="cold">Cold (Below 10°C)</option>
          <option value="moderateCold">Moderately Cold (10–18°C)</option>
          <option value="neutral">Neutral (18–25°C)</option>
          <option value="warm">Warm (25–30°C)</option>
          <option value="hot">Hot (Above 30°C)</option>
          <option value="extremeHot">Extremely Hot (Above 35°C)</option>
        </select>

        <label>Hunger Level:</label>
        <select value={hunger} onChange={(e) => setHunger(e.target.value)}>
          <option value="low">Low</option>
          <option value="normal">Normal</option>
          <option value="high">High</option>
        </select>

        <label>Activity Level:</label>
        <select
          value={activityLevel}
          onChange={(e) => setActivityLevel(parseFloat(e.target.value))}
        >
          <option value={1}>Basal Metabolic Rate (BMR)</option>
          <option value={1.2}>Sedentary: little or no exercise</option>
          <option value={1.375}>Light: exercise 1-3 times/week</option>
          <option value={1.465}>Moderate: exercise 4-5 times/week</option>
          <option value={1.55}>
            Active: daily exercise or intense exercise 3-4 times/week
          </option>
          <option value={1.725}>
            Very Active: intense exercise 6-7 times/week
          </option>
          <option value={1.9}>
            Extra Active: very intense exercise or physical job
          </option>
        </select>

        <label>Goal:</label>
        <select value={goal} onChange={(e) => setGoal(e.target.value)}>
          <option value="m">Maintain weight</option>
          <option value="l">Mild weight loss</option>
          <option value="l1">Weight loss 1 lb/week</option>
          <option value="l2">Extreme weight loss</option>
          <option value="g">Mild weight gain</option>
          <option value="g1">Weight gain 1 lb/week</option>
          <option value="g2">Extreme weight gain</option>
        </select>

        <label>Macro Type:</label>
        <select
          value={macroType}
          onChange={(e) => {
            setMacroType(e.target.value);
            calculateMacros(); // 🔥 intentional recalculation
          }}
        >
          <option value="balanced">Balanced</option>
          <option value="lowFat">Low Fat</option>
          <option value="lowCarb">Low Carb</option>
          <option value="highProtein">High Protein</option>
        </select>

        <button onClick={calculateMacros}>Calculate</button>
      </div>

      {mealInfo && (
        <div className="meal-box">
          <h3>Current Meal: {mealInfo.meal}</h3>
          <p>
            Meal Calories Range: {mealInfo.min} – {mealInfo.max} kcal
          </p>
          <p>
            <b>Selected (Hunger-based): {mealInfo.selected} kcal</b>
          </p>
        </div>
      )}

      {results && mealInfo && (
        <div className="results">
          <h2>Results</h2>

          {/* Day summary stays */}
          <h3>Total Calories: {results.totalCalories} kcal/day</h3>

          {/* 🔥 MEAL-WISE MACROS */}
          <h3>{mealInfo.meal} Macros</h3>

          <p>
            <b>Protein:</b> {results.mealProteinSelected.toFixed(1)} g
            <span style={{ color: "#666" }}>
              {" "}
              ({results.mealProteinRange.min.toFixed(1)} –{" "}
              {results.mealProteinRange.max.toFixed(1)} g)
            </span>
          </p>

          <p>
            <b>Carbs:</b> {results.mealCarbSelected.toFixed(1)} g
            <span style={{ color: "#666" }}>
              {" "}
              ({results.mealCarbRange.min.toFixed(1)} –{" "}
              {results.mealCarbRange.max.toFixed(1)} g)
            </span>
          </p>

          <p>
            <b>Fat:</b> {results.mealFatSelected.toFixed(1)} g
            <span style={{ color: "#666" }}>
              {" "}
              ({results.mealFatRange.min.toFixed(1)} –{" "}
              {results.mealFatRange.max.toFixed(1)} g)
            </span>
          </p>

          {/* Sliders remain DAY-WISE */}
          <Slid
            results={results}
            setResults={setResults}
            mealCalories={mealInfo.selected}
          />
        </div>
      )}
    </div>
  );
}

export default Macro;

// import React from "react";
// import "../styles/slid.css";

// /* =====================================================
//    CALORIE CONVERSION CONSTANTS
//    Calories per gram for each macronutrient.
//    These values are aligned with the Macro calculator.
// ===================================================== */
// const KCAL = {
//   protein: 4.1,
//   carbs: 3.75,
//   fat: 8.8,
// };

// /* Utility function to keep values within allowed range */
// const clamp = (val, min, max) => Math.min(Math.max(val, min), max);

// function Slid({ results, setResults }) {
//   /* Total daily calories must remain constant */
//   const calorieNeeded = Number(results.totalCalories);

//   /* =====================================================
//      Helper to update macro values while preserving ranges
//   ===================================================== */
//   const updateResults = (protein, carbs, fat) => {
//     setResults((prev) => ({
//       ...prev,
//       protein,
//       carbs,
//       fat,
//     }));
//   };

//   /* =====================================================
//      PROTEIN SLIDER LOGIC
//      - Protein is directly controlled by the user
//      - Remaining calories are redistributed to carbs & fat
//      - Macro min/max ranges are strictly enforced
//   ===================================================== */
//   const slideProtein = (value) => {
//     let protein = Number(value);

//     /* Remaining calories after fixing protein */
//     let remaining = calorieNeeded - protein * KCAL.protein;

//     /* Distribute remaining calories proportionally */
//     let carbs =
//       (remaining * results.carbs) /
//       (results.carbs * KCAL.carbs + results.fat * KCAL.fat);

//     let fat =
//       (remaining * results.fat) /
//       (results.carbs * KCAL.carbs + results.fat * KCAL.fat);

//     /* Enforce fat range first */
//     if (fat < results.fatRange.min) {
//       fat = results.fatRange.min;
//       carbs = (remaining - fat * KCAL.fat) / KCAL.carbs;
//     } else if (fat > results.fatRange.max) {
//       fat = results.fatRange.max;
//       carbs = (remaining - fat * KCAL.fat) / KCAL.carbs;
//     }

//     /* Enforce carb range next */
//     if (carbs < results.carbsRange.min) {
//       carbs = results.carbsRange.min;
//       fat = (remaining - carbs * KCAL.carbs) / KCAL.fat;

//       /* Fallback: adjust protein if both ranges are hit */
//       if (fat < results.fatRange.min) {
//         fat = results.fatRange.min;
//         protein =
//           (calorieNeeded -
//             carbs * KCAL.carbs -
//             fat * KCAL.fat) /
//           KCAL.protein;
//       }
//     } else if (carbs > results.carbsRange.max) {
//       carbs = results.carbsRange.max;
//       fat = (remaining - carbs * KCAL.carbs) / KCAL.fat;

//       if (fat > results.fatRange.max) {
//         fat = results.fatRange.max;
//         protein =
//           (calorieNeeded -
//             carbs * KCAL.carbs -
//             fat * KCAL.fat) /
//           KCAL.protein;
//       }
//     }

//     updateResults(
//       clamp(protein, results.proteinRange.min, results.proteinRange.max),
//       clamp(carbs, results.carbsRange.min, results.carbsRange.max),
//       clamp(fat, results.fatRange.min, results.fatRange.max)
//     );
//   };

//   /* =====================================================
//      CARB SLIDER LOGIC
//      - Carbs are fixed by the user
//      - Fat is adjusted first
//      - Protein is protected by its min/max range
//   ===================================================== */
//   const slideCarb = (value) => {
//     let carbs = Number(value);

//     /* Remaining calories after fixing carbs */
//     let remaining = calorieNeeded - carbs * KCAL.carbs;

//     let fat =
//       (remaining - results.protein * KCAL.protein) / KCAL.fat;

//     let protein = results.protein;

//     /* Enforce fat range */
//     if (fat < results.fatRange.min) {
//       fat = results.fatRange.min;
//       protein = (remaining - fat * KCAL.fat) / KCAL.protein;

//       if (protein < results.proteinRange.min) {
//         protein = results.proteinRange.min;
//         carbs =
//           (calorieNeeded -
//             protein * KCAL.protein -
//             fat * KCAL.fat) /
//           KCAL.carbs;
//       }
//     } else if (fat > results.fatRange.max) {
//       fat = results.fatRange.max;
//       protein = (remaining - fat * KCAL.fat) / KCAL.protein;

//       if (protein > results.proteinRange.max) {
//         protein = results.proteinRange.max;
//         carbs =
//           (calorieNeeded -
//             protein * KCAL.protein -
//             fat * KCAL.fat) /
//           KCAL.carbs;
//       }
//     }

//     updateResults(
//       clamp(protein, results.proteinRange.min, results.proteinRange.max),
//       clamp(carbs, results.carbsRange.min, results.carbsRange.max),
//       clamp(fat, results.fatRange.min, results.fatRange.max)
//     );
//   };

//   /* =====================================================
//      FAT SLIDER LOGIC
//      - Fat is fixed by the user
//      - Remaining calories are split between protein & carbs
//      - Protein constraints are applied first
//   ===================================================== */
//   const slideFat = (value) => {
//     let fat = Number(value);

//     /* Remaining calories after fixing fat */
//     let remaining = calorieNeeded - fat * KCAL.fat;

//     let carbs =
//       (remaining * results.carbs) /
//       (results.carbs * KCAL.carbs +
//         results.protein * KCAL.protein);

//     let protein =
//       (remaining * results.protein) /
//       (results.carbs * KCAL.carbs +
//         results.protein * KCAL.protein);

//     /* Enforce protein range */
//     if (protein < results.proteinRange.min) {
//       protein = results.proteinRange.min;
//       carbs = (remaining - protein * KCAL.protein) / KCAL.carbs;
//     } else if (protein > results.proteinRange.max) {
//       protein = results.proteinRange.max;
//       carbs = (remaining - protein * KCAL.protein) / KCAL.carbs;
//     }

//     /* Enforce carb range */
//     if (carbs < results.carbsRange.min) {
//       carbs = results.carbsRange.min;
//       protein = (remaining - carbs * KCAL.carbs) / KCAL.protein;

//       if (protein < results.proteinRange.min) {
//         protein = results.proteinRange.min;
//         fat =
//           (calorieNeeded -
//             carbs * KCAL.carbs -
//             protein * KCAL.protein) /
//           KCAL.fat;
//       }
//     } else if (carbs > results.carbsRange.max) {
//       carbs = results.carbsRange.max;
//       protein = (remaining - carbs * KCAL.carbs) / KCAL.protein;

//       if (protein > results.proteinRange.max) {
//         protein = results.proteinRange.max;
//         fat =
//           (calorieNeeded -
//             carbs * KCAL.carbs -
//             protein * KCAL.protein) /
//           KCAL.fat;
//       }
//     }

//     updateResults(
//       clamp(protein, results.proteinRange.min, results.proteinRange.max),
//       clamp(carbs, results.carbsRange.min, results.carbsRange.max),
//       clamp(fat, results.fatRange.min, results.fatRange.max)
//     );
//   };

//   return (
//     <table className="panel">
//       <tbody>
//         <tr>
//           <td colSpan="2">
//             <b>Slide the bars to create your own plan</b>
//           </td>
//         </tr>

//         <tr>
//           <td>Protein:</td>
//           <td>
//             <input
//               type="range"
//               min={results.proteinRange.min}
//               max={results.proteinRange.max}
//               step="0.01"
//               value={results.protein}
//               onChange={(e) => slideProtein(e.target.value)}
//             />
//           </td>
//         </tr>

//         <tr>
//           <td>Carbs:</td>
//           <td>
//             <input
//               type="range"
//               min={results.carbsRange.min}
//               max={results.carbsRange.max}
//               step="0.01"
//               value={results.carbs}
//               onChange={(e) => slideCarb(e.target.value)}
//             />
//           </td>
//         </tr>

//         <tr>
//           <td>Fat:</td>
//           <td>
//             <input
//               type="range"
//               min={results.fatRange.min}
//               max={results.fatRange.max}
//               step="0.01"
//               value={results.fat}
//               onChange={(e) => slideFat(e.target.value)}
//             />
//           </td>
//         </tr>
//       </tbody>
//     </table>
//   );
// }

// export default Slid;


import React from "react";
import "../styles/slid.css";

/* ================= CALORIE CONSTANTS ================= */
const KCAL = {
  protein: 4.1,
  carbs: 3.75,
  fat: 8.8,
};

/* Clamp helper */
const clamp = (val, min, max) => Math.min(Math.max(val, min), max);

function Slid({ results, setResults, mealCalories }) {
  /* Meal calories must remain constant */
  const calorieNeeded = Number(mealCalories);

  /* ================= UPDATE MEAL MACROS ================= */
  const updateMealMacros = (protein, carbs, fat) => {
    setResults((prev) => ({
      ...prev,
      mealProteinSelected: protein,
      mealCarbSelected: carbs,
      mealFatSelected: fat,
    }));
  };

  /* ================= PROTEIN SLIDER ================= */
  const slideProtein = (value) => {
    let protein = Number(value);

    let remaining = calorieNeeded - protein * KCAL.protein;

    let carbs =
      (remaining * results.mealCarbSelected) /
      (results.mealCarbSelected * KCAL.carbs +
        results.mealFatSelected * KCAL.fat);

    let fat =
      (remaining * results.mealFatSelected) /
      (results.mealCarbSelected * KCAL.carbs +
        results.mealFatSelected * KCAL.fat);

    /* Enforce fat range */
    if (fat < results.mealFatRange.min) {
      fat = results.mealFatRange.min;
      carbs = (remaining - fat * KCAL.fat) / KCAL.carbs;
    } else if (fat > results.mealFatRange.max) {
      fat = results.mealFatRange.max;
      carbs = (remaining - fat * KCAL.fat) / KCAL.carbs;
    }

    /* Enforce carb range */
    if (carbs < results.mealCarbRange.min) {
      carbs = results.mealCarbRange.min;
      fat = (remaining - carbs * KCAL.carbs) / KCAL.fat;
    } else if (carbs > results.mealCarbRange.max) {
      carbs = results.mealCarbRange.max;
      fat = (remaining - carbs * KCAL.carbs) / KCAL.fat;
    }

    updateMealMacros(
      clamp(protein, results.mealProteinRange.min, results.mealProteinRange.max),
      clamp(carbs, results.mealCarbRange.min, results.mealCarbRange.max),
      clamp(fat, results.mealFatRange.min, results.mealFatRange.max)
    );
  };

  /* ================= CARB SLIDER ================= */
  const slideCarb = (value) => {
    let carbs = Number(value);

    let remaining = calorieNeeded - carbs * KCAL.carbs;

    let fat =
      (remaining - results.mealProteinSelected * KCAL.protein) / KCAL.fat;

    let protein = results.mealProteinSelected;

    /* Enforce fat range */
    if (fat < results.mealFatRange.min) {
      fat = results.mealFatRange.min;
      protein = (remaining - fat * KCAL.fat) / KCAL.protein;
    } else if (fat > results.mealFatRange.max) {
      fat = results.mealFatRange.max;
      protein = (remaining - fat * KCAL.fat) / KCAL.protein;
    }

    updateMealMacros(
      clamp(protein, results.mealProteinRange.min, results.mealProteinRange.max),
      clamp(carbs, results.mealCarbRange.min, results.mealCarbRange.max),
      clamp(fat, results.mealFatRange.min, results.mealFatRange.max)
    );
  };

  /* ================= FAT SLIDER ================= */
  const slideFat = (value) => {
    let fat = Number(value);

    let remaining = calorieNeeded - fat * KCAL.fat;

    let carbs =
      (remaining * results.mealCarbSelected) /
      (results.mealCarbSelected * KCAL.carbs +
        results.mealProteinSelected * KCAL.protein);

    let protein =
      (remaining * results.mealProteinSelected) /
      (results.mealCarbSelected * KCAL.carbs +
        results.mealProteinSelected * KCAL.protein);

    /* Enforce protein range */
    if (protein < results.mealProteinRange.min) {
      protein = results.mealProteinRange.min;
      carbs = (remaining - protein * KCAL.protein) / KCAL.carbs;
    } else if (protein > results.mealProteinRange.max) {
      protein = results.mealProteinRange.max;
      carbs = (remaining - protein * KCAL.protein) / KCAL.carbs;
    }

    updateMealMacros(
      clamp(protein, results.mealProteinRange.min, results.mealProteinRange.max),
      clamp(carbs, results.mealCarbRange.min, results.mealCarbRange.max),
      clamp(fat, results.mealFatRange.min, results.mealFatRange.max)
    );
  };

  return (
    <table className="panel">
      <tbody>
        <tr>
          <td colSpan="2">
            <b>Slide the bars to customize this meal</b>
          </td>
        </tr>

        <tr>
          <td>Protein:</td>
          <td>
            <input
              type="range"
              min={results.mealProteinRange.min}
              max={results.mealProteinRange.max}
              step="0.01"
              value={results.mealProteinSelected}
              onChange={(e) => slideProtein(e.target.value)}
            />
          </td>
        </tr>

        <tr>
          <td>Carbs:</td>
          <td>
            <input
              type="range"
              min={results.mealCarbRange.min}
              max={results.mealCarbRange.max}
              step="0.01"
              value={results.mealCarbSelected}
              onChange={(e) => slideCarb(e.target.value)}
            />
          </td>
        </tr>

        <tr>
          <td>Fat:</td>
          <td>
            <input
              type="range"
              min={results.mealFatRange.min}
              max={results.mealFatRange.max}
              step="0.01"
              value={results.mealFatSelected}
              onChange={(e) => slideFat(e.target.value)}
            />
          </td>
        </tr>
      </tbody>
    </table>
  );
}

export default Slid;

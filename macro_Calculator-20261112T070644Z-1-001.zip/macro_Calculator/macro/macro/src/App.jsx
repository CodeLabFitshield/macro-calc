import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Macro from "./components/macro";

const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Macro />} />
      </Routes>
    </Router>
  );
};

export default App;
